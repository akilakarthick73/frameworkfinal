package pageObjects;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class SearchPage {

	public WebDriver driver;
	
	public SearchPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	//locators
	
	private By search = By.xpath("//input[@type='search']");
	private By homePage = By.cssSelector("h4.product-name");
	private By AddtoCartButton = By.xpath("//button[text()='ADD TO CART']");
	private By CartButton = By.className("cart-icon");
	By ProceedButton = By.xpath("//button[text()='PROCEED TO CHECKOUT']");
	By increaseCartButton = By.cssSelector("a.increment");
	//Methods
	
	public void PerformSearch(String searchvalue) throws InterruptedException
	{
		driver.findElement(search).sendKeys(searchvalue);
		driver.findElement(search).sendKeys(Keys.ENTER);
		Thread.sleep(1000);
	}
	
	public String Gettext()
	{
		return driver.findElement(homePage).getText();
		
	}
	
	public void ClickAddToCart()
	{
		driver.findElement(AddtoCartButton).click();
	}
	
	public void NavigateCartsPage() throws InterruptedException
	{
		driver.findElement(CartButton).click();
		driver.findElement(ProceedButton).click();
		Thread.sleep(1000);
	}
	
	public String GetDriverTitle()
	{
		return driver.getTitle();
	}
	
	public void increaseValue(int quantity)
	{
		int i =quantity-1;
		while(i>0)
		{
			driver.findElement(increaseCartButton).click();
			i--;
		}
	}
	
}
