package stepDefinitions;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.SearchPage;
import utils.TestContextSetup;

public class searchSteps {
	public WebDriver driver;
	public SearchPage searchPage;
	
	
	TestContextSetup testContextSetup;
	
	
	public searchSteps(TestContextSetup testContextSetup)
	{
		this.testContextSetup = testContextSetup;
		searchPage = testContextSetup.pageobjectmanager.GetSearchPage();
		
	}
	
	@Given("user is on greencart landing page")
	public void user_is_on_greencart_landing_page() {
		
	    testContextSetup.genericUtils.MaximizeWindow();
	    Assert.assertTrue(searchPage.GetDriverTitle().contains("GreenKart"));
	}
	
	@When("^user search with short name (.+) and extracted actual name$")
	public void user_search_with_short_name_and_extracted_actual_name(String searchvalue) throws InterruptedException {
	

		searchPage.PerformSearch(searchvalue);
		String product = searchPage.Gettext().split("-")[0].trim();
		System.out.print(product);
	}
	
	@When("the user added number of items to select the product as {string}")
	public void the_user_increases_the_value_to(String quantity) {
		
		searchPage.increaseValue(Integer.parseInt(quantity));
	  
	}
	
	

}
